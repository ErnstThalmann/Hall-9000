# Words' datasets

The folder provides datasets containing words vocabularies of any kind. Those can be used with examples demonstrating recurrent artificial neural network, like names generator ([rnn_words](../../rnn_words)).

Available datasets are:
* cities.txt – 997 names of US cities taken from the list of [1000 most populated cities](https://www.biggestuscities.com/).
